Ext.onReady(function() {
	
	if ((typeof Range !== "undefined") && !Range.prototype.createContextualFragment)
	{
	    Range.prototype.createContextualFragment = function(html)
	    {
	        var frag = document.createDocumentFragment(),
	        div = document.createElement("div");
	        frag.appendChild(div);
	        div.outerHTML = html;
	        return frag;
	    };
	};
	
	Ext.state.Manager.setProvider(new Ext.state.CookieProvider());
	//center�����ӵ����ӵ�ַ�б�
	var centerUrls = [
	    ["1.0.jsp","1.1.jsp","1.2.jsp","1.3.jsp","1.4.jsp","1.5.jsp","1.6.jsp"],
	    ["2.0.jsp","2.1.jsp","2.2.jsp","2.3.jsp","2.4.jsp","2.5.jsp","2.6.jsp"],
	    ["3.0.jsp","3.1.jsp","3.2.jsp","3.3.jsp"],
	    ["4.0.jsp","4.1.jsp","4.2.jsp"],
	    ["5.0.jsp"],
	    ["6.0.jsp","6.1.jsp","6.2.jsp","6.3.jsp","6.4.jsp","6.5.jsp","6.6.jsp","6.7.jsp","6.8.jsp"],
	    ["7.0.jsp","7.1.jsp","7.2.jsp","7.3.jsp","7.4.jsp","7.5.jsp","7.6.jsp","7.7.jsp"],
	    ["8.0.jsp","8.1.jsp","8.2.jsp","8.3.jsp","8.4.jsp","8.5.jsp","8.6.jsp"],
	    ["9.0.jsp","9.1.jsp","9.2.jsp"]
	 ];
	var centerHtmlUrls = [
	    ["1.0.html","1.1.html","1.2.html","1.3.html","1.4.html","1.5.html","1.6.html"],
	    ["2.0.html","2.1.html","2.2.html","2.3.html","2.4.html","2.5.html","2.6.html"],
	    ["3.0.html","3.1.html","3.2.html","3.3.html"],
	    ["4.0.html","4.1.html","4.2.html"],
	    ["5.0.html"],
	    ["6.0.html","6.1.html","6.2.html","6.3.html","6.4.html","6.5.html","6.6.html","6.7.html","6.8.html"],
	    ["7.0.html","7.1.html","7.2.html","7.3.html","7.4.html","7.5.html","7.6.html","7.7.html"],
	    ["8.0.html","8.1.html","8.2.html","8.3.html","8.4.html","8.5.html","8.6.html"],
	    ["9.0.html","9.1.html","9.2.html"]
	];
	// center����tab
	var centerTab= null;

	var viewport = new Ext.Viewport({
		layout : 'border',
		items : [new Ext.BoxComponent({
							region : 'north',
							el : 'north',
							height : 32
						}), {
					region : 'west',
					id : 'west-panel',
					title : '���ܲ�����',
					split : true,
					width : 200,
					minSize : 175,
					maxSize : 400,
					collapsible : true,
					margins : '0 0 0 5',
					layout : 'accordion',
					layoutConfig : {
						animate : true
					},
					items : [{
						contentEl : 'west',
						title : '��ͼ��������',
						border : false,
						items : [{
									html : "<a href='#' class='submenu' href='#'>һ��������</a>",
									height : 22,
									border : true

								}, {
									html : "<a href='#' class='submenu' href='#'>�Ŵ��ͼ</a>",
									height : 22,
									border : true
								}, {
									html : "<a href='#' class='submenu' href='#'>����Ŵ��ͼ</a>",
									height : 22,
									border : true
								}, {
									html : "<a href='#' class='submenu' href='#'>��С��ͼ</a>",
									height : 22,
									border : true
								}, {
									html : "<a href='#' class='submenu' href='#'>������С��ͼ</a>",
									height : 22,
									border : true
								}, {
									html : "<a href='#' class='submenu' href='#'>���е�ͼ</a>",
									height : 22,
									border : true
								}, {
									html : "<a href='#' class='submenu' href='#'>��ʾ��ͼȫͼ</a>",
									height : 22,
									border : true
								}]

					}, {
						title : '��ͼ����״̬',
						border : false,
						items : [{
									html : "<a href='#' class='submenu' href='#'>����ƽ��״̬</a>",
									height : 22,
									border : true
								}, {
									html : "<a href='#' class='submenu' href='#'>��������״̬</a>",
									height : 22,
									border : true
								}, {
									html : "<a href='#' class='submenu' href='#'>��ȡ���������״̬</a>",
									height : 22,
									border : true
								}, {
									html : "<a href='#' class='submenu' href='#'>����״̬</a>",
									height : 22,
									border : true
								}, {
									html : "<a href='#' class='submenu' href='#'>������״̬</a>",
									height : 22,
									border : true
								}, {
									html : "<a href='#' class='submenu' href='#'>�������״̬</a>",
									height : 22,
									border : true
								}, {
									html : "<a href='#' class='submenu' href='#'>��Բ״̬</a>",
									height : 22,
									border : true
								}]
					}, {
						title : '��ͼ�����ؼ�',
						border : false,
						items : [{
									html : "<a href='#' class='submenu' href='#'>��ʾһ���ͼ�����ؼ�</a>",
									height : 22,
									border : true

								}, {
									html : "<a href='#' class='submenu' href='#'>��ʾ�򻯵�ͼ�����ؼ�</a>",
									height : 22,
									border : true
								}, {
									html : "<a href='#' class='submenu' href='#'>��ʾ��׼��ͼ�����ؼ�</a>",
									height : 22,
									border : true
								}, {
									html : "<a href='#' class='submenu' href='#'>���ص�ͼ�����ؼ�</a>",
									height : 22,
									border : true
								}]
					}, {
						title : 'ӥ����ʾ',
						border : false,
						items : [{
									html : "<a href='#' class='submenu' href='#'>��ʼ������ӥ��</a>",
									height : 22,
									border : true

								}, {
									html : "<a href='#' class='submenu' href='#'>��ʾӥ��</a>",
									height : 22,
									border : true
								}, {
									html : "<a href='#' class='submenu' href='#'>����ӥ��</a>",
									height : 22,
									border : true
								}]
					}, {
						title : 'ר��ͼ����',
						border : false,
						items : [{
									html : "<a href='#' class='submenu' href='#'>ר��ͼ����</a>",
									height : 22,
									border : true
								}]
					}, {
						title : '������ͼ�¼�',
						border : false,
						items : [{
									html : "<a href='#' class='submenu' href='#'>������ͼ�¼�</a>",
									height : 22,
									border : true
								}, {
									html : "<a href='#' class='submenu' href='#'>mapready�¼�</a>",
									height : 22,
									border : true
								}, {
									html : "<a href='#' class='submenu' href='#'>mapclick�¼�</a>",
									height : 22,
									border : true
								}, {
									html : "<a href='#' class='submenu' href='#'>mapdblclick�¼�</a>",
									height : 22,
									border : true
								}, {
									html : "<a href='#' class='submenu' href='#'>mapmousedown�¼�</a>",
									height : 22,
									border : true
								}, {
									html : "<a href='#' class='submenu' href='#'>mapmouseup�¼�</a>",
									height : 22,
									border : true
								}, {
									html : "<a href='#' class='submenu' href='#'>mapswitchmapserver�¼�</a>",
									height : 22,
									border : true
								}, {
									html : "<a href='#' class='submenu' href='#'>mappanend�¼�</a>",
									height : 22,
									border : true
								}, {
									html : "<a href='#' class='submenu' href='#'>mapzoomchange�¼�</a>",
									height : 22,
									border : true
								}]
						
					}, {
						title : '���ε��Ӷ���',
						border : false,
						items : [{
									html : "<a href='#' class='submenu' href='#'>��ǵ�����</a>",
									height : 22,
									border : true
								}, {
									html : "<a href='#' class='submenu' href='#'>�����ߵ�����</a>",
									height : 22,
									border : true
								}, {
									html : "<a href='#' class='submenu' href='#'>���ε�����</a>",
									height : 22,
									border : true
								}, {
									html : "<a href='#' class='submenu' href='#'>����ε�����</a>",
									height : 22,
									border : true
								}, {
									html : "<a href='#' class='submenu' href='#'>Բ�ε�����</a>",
									height : 22,
									border : true
								}, {
									html : "<a href='#' class='submenu' href='#'>�ı�������</a>",
									height : 22,
									border : true
								}, {
									html : "<a href='#' class='submenu' href='#'>����HTML DOM������</a>",
									height : 22,
									border : true
								}]
					}, {
						title : '�ռ����ݲ�ѯ',
						border : false,
						items : [{
									html : "<a href='#' class='submenu' href='#'>���ѯ</a>",
									height : 22,
									border : true
								}, {
									html : "<a href='#' class='submenu' href='#'>�����ѯ</a>",
									height : 22,
									border : true
								}, {
									html : "<a href='#' class='submenu' href='#'>Բ�β�ѯ</a>",
									height : 22,
									border : true
								}, {
									html : "<a href='#' class='submenu' href='#'>����β�ѯ</a>",
									height : 22,
									border : true
								}, {
									html : "<a href='#' class='submenu' href='#'>���ܱ߲�ѯ</a>",
									height : 22,
									border : true
								}, {
									html : "<a href='#' class='submenu' href='#'>���ܱ߲�ѯ</a>",
									height : 22,
									border : true
								}, {
									html : "<a href='#' class='submenu' href='#'>�����ز�ѯ</a>",
									height : 22,
									border : true
								}]
					}, {
						title : '�ռ����ݱ༭',
						border : false,
						items : [{
									html : "<a href='#' class='submenu' href='#'>����</a>",
									height : 22,
									border : true
								}, {
									html : "<a href='#' class='submenu' href='#'>ɾ��</a>",
									height : 22,
									border : true
								}, {
									html : "<a href='#' class='submenu' href='#'>����</a>",
									height : 22,
									border : true
							}]
					}]
				}, new Ext.Panel({
							region : 'center',
							autoScroll : true,
							contentEl : "center"
						})]
	});
	
	/**
	 * �������д���Ƭ��
	 */
	Jet().$package("playground",function(J){
		var $D = J.dom;
		this.runCode = function(htmlCode){
			var CodeRunContainer = window.frames["if2"];
			var CodeEditor = window.frames["if1"].document.getElementById("txtComments");
			htmlCode = htmlCode || CodeEditor.value;
			CodeRunContainer.document.open("text/html","replace"); 
			CodeRunContainer.document.write(htmlCode) 
			CodeRunContainer.document.close(); 
		};

	});
	/**
	 * subMenu����ص����������ڸ���������
	 */
	function subMenuCallback(m,n) {
		//�����ǰcenter�� ��tabs
		if (centerTab){
			centerTab.destroy();
		}
	
		if(m==0&&n==5){
			//����һ��tabҳ
			centerTab = new Ext.TabPanel({
				activeTab : 0,
				items : [{
					title : '�Զ����¼�˵��&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;',
					autoScroll : true,
					html : '<iframe id="if1" name="if1" style="width: 100%;height:730px;overflow: visible" frameborder="0" src="jspsection/'+ centerUrls[n][m] + '"></iframe>'
				}]
			});
		}else{
			// ��������tabҳ
			centerTab = new Ext.TabPanel({
				activeTab : 0,
				items : [{
					title : '����&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;',
					autoScroll : true,
					style:'height:730px',
					html : '<iframe id="if1" name="if1" style="width: 100%;height:730px;overflow: visible" frameborder="0" src="jspsection/'+ centerUrls[n][m] + '" scrolling="no"></iframe>'
				}, {
					title : '��ͼ&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;',
					html : '<iframe id="if2" name="if2" style="width: 100%;height:730px;overflow: visible" frameborder="0" src="mapsection/'+ centerHtmlUrls[n][m]+'" scrolling="no"></iframe>',
					autoScroll : true
				}]
			});
		}
		centerTab.render(viewport.items.get(2).body);
		centerTab.addListener("tabchange",function(p, tab){
//			if(p.getItem(1) == tab){
//				playground.runCode();
//			}
		})

	}

	/**
	 * �������subMenu�ĵ���¼�
	 */
	viewport.items.get(1).items.each(function(vEleOuter, indexOuter, len){
		if(!vEleOuter.items)return;
		vEleOuter.items.each(function(vEle, index) {
				vEle.getEl().on("click", (function(m,n){
					//���ĵ�����west������ɫ
					return function(){
						subMenuCallback(m,n);
						//vEle.body.dom.childNodes[0].style.color = "#CC0000";
					}})(index,indexOuter));
					
			}, this);
		
	});

	// center���ڳ�ʼ��ʱ������1.0.jsp
	subMenuCallback(0,0);

});
